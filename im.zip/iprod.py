import time
import cv2
from kafka import SimpleProducer, KafkaClient
#  connect to Kafka
kafka = KafkaClient('localhost:9092')
producer = SimpleProducer(kafka)
# Assign a topic
topic = 'my-topic'

def video_emitter(video):
    # Open the video
    #video = cv2.VideoCapture(video)
    print(' emitting.....')

    # read the file
    for i in range(0,30):
        # read the image in each frame
        f = open('vf'+str(i)+'.png')
        im = f.read()
        f.close()
        # Convert the image to bytes and send to kafka
        producer.send_messages(topic, im)
        # To reduce CPU usage create sleep time of 0.2sec
        time.sleep(0.1)
    # clear the capture
    print('done emitting')

if __name__ == '__main__':
    video_emitter('video.mp4')
